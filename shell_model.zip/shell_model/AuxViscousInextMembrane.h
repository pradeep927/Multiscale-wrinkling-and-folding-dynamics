/*
    *******************************************************************************
    Copyright (c) 2017-2021 Universitat Politècnica de Catalunya
    Authors: Daniel Santos-Olivan, Alejandro Torres-Sanchez and Guillermo Vilanova
    Contributors:
    *******************************************************************************
    This file is part of hiperlife - High Performance Library for Finite Elements
    Project homepage: https://git.lacan.upc.edu/HPLFEgroup/hiperlifelib.git
    Distributed under the MIT software license, see the accompanying
    file LICENSE or http://www.opensource.org/licenses/mit-license.php.
    *******************************************************************************
*/


#ifndef AUXPATFOR_H
#define AUXPATFOR_H


#include <iostream>
#include <mpi.h>

#include "hl_DistributedMesh.h"
#include "hl_FillStructure.h"
#include "hl_UserStructure.h"
#include "hl_DOFsHandler.h"
#include "hl_HiPerProblem.h"

#include "hl_Math.h"
#include "hl_Array.h"

using namespace std;
using namespace hiperlife;

using Teuchos::rcp;
using Teuchos::RCP;
void LS_ReacDif(Teuchos::RCP<hiperlife::FillStructure> fillStr);
void LS_ED(RCP<hiperlife::FillStructure> fillStr);
void LS_Rho(RCP<hiperlife::FillStructure> fillStr);

void LS(RCP<hiperlife::FillStructure> fillStr);

#endif


void RHS_Border(Teuchos::RCP<hiperlife::FillStructure> fillStr);




double inline ConfinementPotential(hiperlife::Tensor::tensor<double,1>& x, double Kconf)
{
    double pot{};
    if(x(2)<0)
    {
        pot = -Kconf/3.0 * x(2)*x(2)*x(2);
    }

    return pot;
}

double inline dConfinementPotential(hiperlife::Tensor::tensor<double,1>& x, double Kconf)
{
    using namespace hiperlife;
    using namespace hiperlife::Tensor;
    double dpot{};

    if(x(2)<0)
    {
        dpot =-1*Kconf*x(2)*x(2);
    }



    return dpot;
}

double  inline ddConfinementPotential(hiperlife::Tensor::tensor<double,1>& x, double Kconf)
{
    using namespace hiperlife;
    using namespace hiperlife::Tensor;
    double ddpot{};
    if(x(2)<0)
    {
        ddpot = -2.0*Kconf*x(2);
    }

    return ddpot;
}

double inline zz_max(hiperlife::Tensor::tensor<double,1>& Z_cord1,double size_n)
{
    using namespace hiperlife;
    using namespace hiperlife::Tensor;
    // find minimum

    double  Z_max = Z_cord1(0);
    // search num in inputArray from index 0 to elementCount-1
    for (int i = 0; i < size_n; i++)
    {
        if (Z_cord1(i) > Z_max)
        {
            Z_max = Z_cord1(i);
        }
    }

    return  Z_max;
}

double inline ConfinementPotential1(hiperlife::Tensor::tensor<double,1>& x, double Kconf)
{
    double pot{};
    pot = Kconf/2.0 * x(0)*x(0);
    return pot;
}

double inline dConfinementPotential1(hiperlife::Tensor::tensor<double,1>& x, double Kconf)
{
    using namespace hiperlife;
    using namespace hiperlife::Tensor;
    double dpot{};

    dpot =Kconf*x(0);

    return dpot;
}

double  inline ddConfinementPotential1(hiperlife::Tensor::tensor<double,1>& x, double Kconf)
{
    using namespace hiperlife;
    using namespace hiperlife::Tensor;
    double ddpot{};

    ddpot = Kconf;


    return ddpot;
}


// Define a cross product for 3D tensors
// cross product for 3D tensors
// cross product for 3D tensors

